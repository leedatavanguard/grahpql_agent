"""Configuration settings for the observability module."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings."""
    
    # ClickHouse Configuration
    clickhouse_host: str = "localhost"  # Will be extracted from CH_URL
    clickhouse_port: int = 8443
    clickhouse_user: str = "default"
    clickhouse_password: str = ""
    clickhouse_database: str = "dve"
    clickhouse_ssl: bool = True
    
    # Environment variable mappings
    CH_URL: str
    CH_PORT: int = 8443
    CH_USERNAME: str = "default"
    CH_PASSWORD: str
    CH_DATABASE_NAME: str = "dve"
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Extract host from CH_URL
        self.clickhouse_host = self.CH_URL.replace("https://", "").replace("http://", "")
        self.clickhouse_port = self.CH_PORT
        self.clickhouse_user = self.CH_USERNAME
        self.clickhouse_password = self.CH_PASSWORD
        self.clickhouse_database = self.CH_DATABASE_NAME
        self.clickhouse_ssl = self.CH_URL.startswith("https")
    
    # Data Retention Configuration (in days)
    metrics_retention_days: int = 720
    logs_retention_days: int = 720
    
    # Environment Configuration
    environment: str = "development"
    debug: bool = False
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
    )


settings = Settings()
