"""Models for job metrics and logging."""
from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class JobType(str, Enum):
    """Job type enumeration."""
    
    INGESTION = "ingestion"
    STANDARDIZATION = "standardization"
    PRODUCT = "product"


class JobLogType(str, Enum):
    """Job log type enumeration."""
    
    START = "start"
    COMPLETED = "completed"
    ERROR = "error"
    DATA_CONTRACT_BREACH = "data_contract_breach"


class JobMetrics(BaseModel):
    """Job metrics model."""
    
    dataset_id: str
    job_id: str
    job_type: JobType
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    cost: float
    processing_time_seconds: float
    memory_usage_mb: float
    cpu_usage_percent: float
    rows_processed: int
    throughput_rows_per_second: float
    peak_memory_usage_mb: float
    disk_io_bytes: int
    network_bytes_transferred: int
    error_count: int = 0
    warning_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)


class JobLog(BaseModel):
    """Job log model."""
    
    dataset_id: str
    job_id: str
    type: JobLogType
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    error_message: Optional[str] = ""
    status_details: Optional[str] = ""
    environment: str
    version: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
