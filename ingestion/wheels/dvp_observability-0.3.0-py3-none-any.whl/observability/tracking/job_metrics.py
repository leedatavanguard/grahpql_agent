"""Job metrics tracking and logging to ClickHouse."""

import os
import time
import psutil
import logging
from typing import Optional
from datetime import datetime

from observability.models.job_metrics import JobMetrics, JobLog, JobType, JobLogType
from observability.clickhouse.client import ClickHouseClient

logger = logging.getLogger(__name__)

class JobMetricsTracker:
    """Tracks and logs job execution metrics to ClickHouse."""
    
    def __init__(self, job_id: str, dataset_id: str, job_type: JobType = JobType.INGESTION):
        """Initialize job metrics tracker.
        
        Args:
            job_id: Unique identifier for the job (e.g., handler name)
            dataset_id: Identifier for the dataset being processed
            job_type: Type of job being executed
        """
        self.job_id = job_id
        self.dataset_id = dataset_id
        self.job_type = job_type
        self.start_time: Optional[float] = None
        self.clickhouse = ClickHouseClient()
        
        # Initialize resource tracking
        self.process = psutil.Process()
        self.start_memory = self.process.memory_info().rss / 1024 / 1024  # MB
        self.start_cpu = self.process.cpu_percent()
        
    def start(self):
        """Start tracking job metrics."""
        self.start_time = time.time()
        
        # Log job start event
        log = JobLog(
            dataset_id=self.dataset_id,
            job_id=self.job_id,
            type=JobLogType.START,
            environment=os.environ.get('TARGET_PLATFORM', 'unknown'),
            version=os.environ.get('VERSION', 'unknown')
        )
        try:
            self.clickhouse.client.insert('data_job_logs', [log.model_dump()])
        except Exception as e:
            logger.error(f"Failed to log start event: {str(e)}")
        
    def end(self, status: str, error: Optional[str] = None, rows_processed: int = 0):
        """End job metrics tracking and log results.
        
        Args:
            status: Final job status ('completed' or 'error')
            error: Error message if job failed
            rows_processed: Number of rows processed during the job
        """
        if not self.start_time:
            logger.warning("end() called before start()")
            return
            
        # Calculate resource usage
        end_memory = self.process.memory_info().rss / 1024 / 1024
        memory_used = end_memory - self.start_memory
        
        # Get disk I/O if available
        try:
            end_disk = self.process.io_counters()
            disk_read = end_disk.read_bytes / 1024 / 1024  # MB
            disk_write = end_disk.write_bytes / 1024 / 1024  # MB
        except (AttributeError, psutil.Error):
            disk_read = 0
            disk_write = 0
        
        # Get network I/O if available
        try:
            end_network = psutil.net_io_counters()
            net_recv = end_network.bytes_recv / 1024 / 1024  # MB
            net_sent = end_network.bytes_sent / 1024 / 1024  # MB
        except (AttributeError, psutil.Error):
            net_recv = 0
            net_sent = 0
            
        processing_time = time.time() - self.start_time
        
        # Log final metrics
        metrics = JobMetrics(
            dataset_id=self.dataset_id,
            job_id=self.job_id,
            job_type=self.job_type,
            cost=0.0,  # Set by caller if needed
            processing_time_seconds=processing_time,
            memory_usage_mb=memory_used,
            peak_memory_usage_mb=end_memory,
            cpu_usage_percent=self.process.cpu_percent(),
            disk_io_bytes=int((disk_read + disk_write) * 1024 * 1024),
            network_bytes_transferred=int((net_recv + net_sent) * 1024 * 1024),
            rows_processed=rows_processed,
            throughput_rows_per_second=rows_processed / processing_time if processing_time > 0 else 0.0,
            error_count=1 if error else 0,
            warning_count=0
        )
        try:
            self.clickhouse.client.insert('data_job_metrics', [metrics.model_dump()])
        except Exception as e:
            logger.error(f"Failed to log metrics: {str(e)}")
        
        # Log completion event
        log = JobLog(
            dataset_id=self.dataset_id,
            job_id=self.job_id,
            type=JobLogType.ERROR if error else JobLogType.COMPLETED,
            error_message=error or "",
            status_details=status,
            environment=os.environ.get('TARGET_PLATFORM', 'unknown'),
            version=os.environ.get('VERSION', 'unknown')
        )
        try:
            self.clickhouse.client.insert('data_job_logs', [log.model_dump()])
        except Exception as e:
            logger.error(f"Failed to log completion event: {str(e)}")
            
    def __del__(self):
        """Clean up resources."""
        if hasattr(self, 'clickhouse'):
            self.clickhouse.close()
