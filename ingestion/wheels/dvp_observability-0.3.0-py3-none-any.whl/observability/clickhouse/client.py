"""ClickHouse client for metrics and logging."""
import logging
import os
from typing import Optional, Dict, Any
from urllib.parse import urlparse

import clickhouse_connect
from clickhouse_connect.driver.client import Client
from clickhouse_connect.driver.exceptions import ClickHouseError

from observability.models.job_metrics import JobMetrics, JobLog

logger = logging.getLogger(__name__)


class ClickHouseConfigError(Exception):
    """Raised when there is an error in ClickHouse configuration."""
    pass


class ClickHouseClient:
    """Client for interacting with ClickHouse."""
    
    REQUIRED_ENV_VARS = [
        'CH_DATABASE_NAME',
        'CH_USERNAME',
        'CH_PORT',
        'CH_URL',
        'CH_PASSWORD'
    ]
    
    def __init__(self, client: Optional[Client] = None):
        """Initialize client."""
        if client:
            self.client = client
            return

        # Log all environment variables for debugging
        logger.debug("Current environment variables:")
        for var in self.REQUIRED_ENV_VARS:
            value = os.environ.get(var)
            # Mask password in logs
            if var == 'CH_PASSWORD' and value:
                logger.debug(f"{var}: ****")
            else:
                logger.debug(f"{var}: {value}")

        # Get environment variables
        database = os.getenv("CH_DATABASE_NAME")
        username = os.getenv("CH_USERNAME")
        port = os.getenv("CH_PORT")
        url = os.getenv("CH_URL")
        password = os.getenv("CH_PASSWORD")

        # Validate environment variables
        missing_vars = []
        none_vars = []
        for var in self.REQUIRED_ENV_VARS:
            value = os.environ.get(var)
            if not value:
                missing_vars.append(var)
            elif value.lower() == 'none':
                none_vars.append(var)
        
        error_messages = []
        if missing_vars:
            error_messages.append(
                f"Missing required ClickHouse environment variables: {', '.join(missing_vars)}. "
                "Please ensure these are set in .platform_config/dev_platform/.env"
            )
        if none_vars:
            error_messages.append(
                f"Required ClickHouse environment variables have 'None' values: {', '.join(none_vars)}. "
                "Please ensure these have valid values."
            )
        
        if error_messages:
            error_msg = "\n".join(error_messages)
            logger.error(error_msg)
            raise ClickHouseConfigError(error_msg)

        # Parse URL to get host
        parsed_url = urlparse(url)
        host = parsed_url.netloc or parsed_url.path
        secure = url.startswith('https://')

        logger.info("Initializing ClickHouse client with:")
        logger.info(f"  Host: {host}")
        logger.info(f"  Port: {port}")
        logger.info(f"  Database: {database}")
        logger.info(f"  Username: {username}")
        logger.info(f"  Secure: {secure}")

        # Create client
        try:
            self.client = clickhouse_connect.get_client(
                host=host,
                port=int(port),
                username=username,
                password=password,
                database=database,
                secure=secure,
            )
            # Test connection
            version = self.client.server_version
            logger.info(f"Successfully connected to ClickHouse server version: {version}")
        except ClickHouseError as e:
            error_msg = f"Failed to initialize ClickHouse client: {str(e)}"
            logger.error(error_msg)
            raise ClickHouseConfigError(error_msg)

    def log_metrics(self, metrics: JobMetrics) -> bool:
        """Log job metrics to ClickHouse.
        
        Args:
            metrics: JobMetrics object containing metrics to log
            
        Returns:
            bool: True if metrics were logged successfully, False otherwise
            
        Raises:
            Exception: If client is not initialized
        """
        if not hasattr(self, 'client'):
            error_msg = "ClickHouse client not initialized"
            logger.error(error_msg)
            raise Exception(error_msg)
            
        try:
            self.client.insert('data_job_metrics', [metrics.model_dump()])
            logger.info(
                "Successfully logged metrics to ClickHouse for job %s, dataset %s",
                metrics.job_id,
                metrics.dataset_id
            )
            return True
        except Exception as e:
            logger.error(
                "Failed to log metrics to ClickHouse for job %s: %s",
                metrics.job_id,
                str(e)
            )
            return False
            
    def log_event(self, log: JobLog) -> bool:
        """Log job event to ClickHouse.
        
        Args:
            log: JobLog object containing event details
            
        Returns:
            bool: True if event was logged successfully, False otherwise
            
        Raises:
            Exception: If client is not initialized
        """
        if not hasattr(self, 'client'):
            error_msg = "ClickHouse client not initialized"
            logger.error(error_msg)
            raise Exception(error_msg)
            
        try:
            self.client.insert('data_job_logs', [log.model_dump()])
            logger.info(
                "Successfully logged %s event to ClickHouse for job %s, dataset %s",
                log.type,
                log.job_id,
                log.dataset_id
            )
            return True
        except Exception as e:
            logger.error(
                "Failed to log %s event to ClickHouse for job %s: %s",
                log.type,
                log.job_id,
                str(e)
            )
            return False

    def close(self):
        """Close client connection."""
        if hasattr(self, "client"):
            self.client.close()

    def __del__(self):
        """Clean up resources."""
        self.close()
