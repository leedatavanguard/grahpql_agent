"""Initialize ClickHouse database with required tables."""

import logging
from observability.clickhouse.schema_manager import SchemaManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    """Create required tables in ClickHouse."""
    try:
        schema_manager = SchemaManager()
        schema_manager.create_all_tables()
        logger.info("Successfully created all tables")
    except Exception as e:
        logger.error(f"Failed to create tables: {e}")
        raise

if __name__ == "__main__":
    main()
