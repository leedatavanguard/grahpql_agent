"""ClickHouse schema manager for job tracking system."""
import logging
import os
from typing import Optional

from clickhouse_connect.driver.client import Client
from clickhouse_connect.driver.exceptions import ClickHouseError
from observability.clickhouse.client import ClickHouseClient

logger = logging.getLogger(__name__)


class SchemaManager:
    """Manages ClickHouse schema for job tracking system."""
    
    def __init__(self, client: Optional[Client] = None):
        """Initialize schema manager."""
        self.client = client or ClickHouseClient().client

    def create_database(self, database: str) -> None:
        """Create database if it doesn't exist."""
        try:
            self.client.command(f"CREATE DATABASE IF NOT EXISTS {database}")
            logger.info(f"Ensured database exists: {database}")
        except ClickHouseError as e:
            raise RuntimeError(f"Failed to create database {database}: {e}")

    def create_job_metrics_table(self):
        """Create job metrics table if it doesn't exist."""
        query = """
        CREATE TABLE IF NOT EXISTS data_job_metrics (
            dataset_id String,
            job_id String,
            job_type Enum('ingestion' = 1, 'standardization' = 2, 'product' = 3),
            timestamp DateTime,
            cost Float64,
            processing_time_seconds Float64,
            memory_usage_mb Float64,
            cpu_usage_percent Float64,
            rows_processed UInt64,
            throughput_rows_per_second Float64,
            peak_memory_usage_mb Float64,
            disk_io_bytes UInt64,
            network_bytes_transferred UInt64,
            error_count UInt32 DEFAULT 0,
            warning_count UInt32 DEFAULT 0,
            created_at DateTime DEFAULT now()
        ) ENGINE = MergeTree()
        PARTITION BY toYYYYMM(timestamp)
        ORDER BY (timestamp, dataset_id, job_id)
        TTL timestamp + INTERVAL 720 DAY;
        """
        try:
            self.client.command(query)
            logger.info("Created job_metrics table")
        except ClickHouseError as e:
            logger.error(f"Failed to create job_metrics table: {e}")
            raise

    def create_job_logs_table(self):
        """Create job logs table if it doesn't exist."""
        query = """
        CREATE TABLE IF NOT EXISTS data_job_logs (
            dataset_id String,
            job_id String,
            type Enum('start' = 1, 'completed' = 2, 'error' = 3, 'data_contract_breach' = 4),
            timestamp DateTime,
            error_message String DEFAULT '',
            status_details String DEFAULT '',
            environment String,
            version String,
            created_at DateTime DEFAULT now()
        ) ENGINE = MergeTree()
        PARTITION BY toYYYYMM(timestamp)
        ORDER BY (timestamp, dataset_id, job_id)
        TTL timestamp + INTERVAL 720 DAY;
        """
        try:
            self.client.command(query)
            logger.info("Created job_logs table")
        except ClickHouseError as e:
            logger.error(f"Failed to create job_logs table: {e}")
            raise

    def create_all_tables(self):
        """Create all required tables."""
        try:
            database = os.environ['CH_DATABASE_NAME']
            self.create_database(database)
            # Use the current database
            self.client.command(f"USE {database}")
            self.create_job_metrics_table()
            self.create_job_logs_table()
            logger.info("Created all required tables")
        except Exception as e:
            raise RuntimeError(f"Failed to create tables: {e}")

    def drop_tables(self) -> None:
        """Drop all tables (useful for testing)."""
        try:
            self.client.command("DROP TABLE IF EXISTS data_job_metrics")
            self.client.command("DROP TABLE IF EXISTS data_job_logs")
            logger.info("Dropped all tables")
        except ClickHouseError as e:
            raise RuntimeError(f"Failed to drop tables: {e}")


def main():
    """Main function to create tables."""
    logging.basicConfig(level=logging.INFO)
    try:
        schema_manager = SchemaManager()
        schema_manager.create_all_tables()
        logger.info("Successfully created ClickHouse tables")
    except Exception as e:
        logger.error(f"Failed to create ClickHouse tables: {e}")
        raise


if __name__ == "__main__":
    main()
